<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Invoice;
use App\Models\Transaction;
use Safaricom\Mpesa\Mpesa;

class MpesaController extends Controller
{
    // Function to create an invoice
    public function createInvoice(Request $request)
    {
        // Validate the request data
        $validated = $request->validate([
            'email' => 'required|email',
            'product' => 'required|string',
            'amount' => 'required|numeric',
        ]);

        // Create the invoice using mass assignment
        $invoice = Invoice::create($validated);

        return response()->json($invoice, 201);
    }

    // Function to handle the STK push
    public function stkPush(Request $request)
    {
        // Validate the request data
        $validated = $request->validate([
            'phone' => 'required|string',
            'amount' => 'required|numeric',
            'invoice_id' => 'required|integer'
        ]);

        $mpesa = new Mpesa();

        $BusinessShortCode = config('mpesa.lipa_na_mpesa_online_short_code');
        $LipaNaMpesaPasskey = config('mpesa.lipa_na_mpesa_online_passkey');
        $TransactionType = 'CustomerPayBillOnline';
        $Amount = $validated['amount'];
        $PartyA = $validated['phone'];
        $PartyB = $BusinessShortCode;
        $PhoneNumber = $validated['phone'];
        $CallBackURL = config('mpesa.callback_url');
        $AccountReference = 'Laravel Mpesa';
        $TransactionDesc = 'Laravel Mpesa STK PUSH';
        $Remarks = 'Laravel Mpesa STK PUSH';

        $stkPushSimulation = $mpesa->STKPushSimulation(
            $BusinessShortCode,
            $LipaNaMpesaPasskey,
            $TransactionType,
            $Amount,
            $PartyA,
            $PartyB,
            $PhoneNumber,
            $CallBackURL,
            $AccountReference,
            $TransactionDesc,
            $Remarks
        );

        if (is_string($stkPushSimulation)) {
            $stkPushSimulation = json_decode($stkPushSimulation, true);
        }

        // Save transaction details in the transactions table
        $invoice = Invoice::find($validated['invoice_id']);
        if ($invoice) {
            $invoice->transactions()->create([
                'phone' => $PartyA,
                'amount' => $Amount,
                'status' => 'Pending',
                'merchant_request_id' => $stkPushSimulation['MerchantRequestID'] ?? '',
                'checkout_request_id' => $stkPushSimulation['CheckoutRequestID'] ?? '',
                'response_code' => $stkPushSimulation['ResponseCode'] ?? '',
                'response_description' => $stkPushSimulation['ResponseDescription'] ?? '',
                'customer_message' => $stkPushSimulation['CustomerMessage'] ?? '',
            ]);

            // Update invoice status to 'Paid' if the payment is successful
            if ($stkPushSimulation['ResponseCode'] == '0') {
                $invoice->status = 'Paid';
                $invoice->save();
            }
        }

        return response()->json($stkPushSimulation);
    }

    // Function to get all invoices
    public function getInvoices()
    {
        $invoices = Invoice::all();
        return response()->json($invoices);
    }

    // Function to delete an invoice
    public function deleteInvoice($id)
    {
        $invoice = Invoice::find($id);
        if ($invoice) {
            $invoice->delete();
            return response()->json(['message' => 'Invoice deleted successfully']);
        } else {
            return response()->json(['message' => 'Invoice not found'], 404);
        }
    }
}
